﻿namespace Astronomical_Data_Processing
{
    partial class DataProcessing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataProcessing));
            this.loadSensorData = new System.Windows.Forms.Button();
            this.sensorListView = new System.Windows.Forms.ListView();
            this.Sensor_A = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Sensor_B = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.sensorAIterativeSearch = new System.Windows.Forms.Button();
            this.sensorAListBox = new System.Windows.Forms.ListBox();
            this.sensorBListBox = new System.Windows.Forms.ListBox();
            this.sensorARecursiveSearch = new System.Windows.Forms.Button();
            this.sensorASelectionSort = new System.Windows.Forms.Button();
            this.sensorAInsertionSort = new System.Windows.Forms.Button();
            this.sensorBIterativeSearch = new System.Windows.Forms.Button();
            this.sensorBRecursiveSearch = new System.Windows.Forms.Button();
            this.sensorBSelectionSort = new System.Windows.Forms.Button();
            this.sensorBInsertionSort = new System.Windows.Forms.Button();
            this.sigmaUpDown = new System.Windows.Forms.NumericUpDown();
            this.muUpDown = new System.Windows.Forms.NumericUpDown();
            this.sensorAIterativeText = new System.Windows.Forms.TextBox();
            this.sensorBIterativeText = new System.Windows.Forms.TextBox();
            this.sensorARecursiveText = new System.Windows.Forms.TextBox();
            this.sensorBRecursiveText = new System.Windows.Forms.TextBox();
            this.sensorASelectionText = new System.Windows.Forms.TextBox();
            this.sensorBSelectionText = new System.Windows.Forms.TextBox();
            this.sensorAInsertionText = new System.Windows.Forms.TextBox();
            this.sensorBInsertionText = new System.Windows.Forms.TextBox();
            this.searchTargetAText = new System.Windows.Forms.TextBox();
            this.searchTargetBText = new System.Windows.Forms.TextBox();
            this.Sigma = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sigmaUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.muUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // loadSensorData
            // 
            this.loadSensorData.Location = new System.Drawing.Point(50, 64);
            this.loadSensorData.Name = "loadSensorData";
            this.loadSensorData.Size = new System.Drawing.Size(121, 23);
            this.loadSensorData.TabIndex = 0;
            this.loadSensorData.Text = "Load Sensor Data";
            this.loadSensorData.UseVisualStyleBackColor = true;
            this.loadSensorData.Click += new System.EventHandler(this.loadSensorData_Click);
            // 
            // sensorListView
            // 
            this.sensorListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Sensor_A,
            this.Sensor_B});
            this.sensorListView.HideSelection = false;
            this.sensorListView.Location = new System.Drawing.Point(26, 93);
            this.sensorListView.Name = "sensorListView";
            this.sensorListView.Size = new System.Drawing.Size(170, 446);
            this.sensorListView.TabIndex = 1;
            this.sensorListView.UseCompatibleStateImageBehavior = false;
            this.sensorListView.View = System.Windows.Forms.View.Details;
            // 
            // Sensor_A
            // 
            this.Sensor_A.Text = "Sensor A";
            this.Sensor_A.Width = 73;
            // 
            // Sensor_B
            // 
            this.Sensor_B.Text = "Sensor B";
            this.Sensor_B.Width = 73;
            // 
            // sensorAIterativeSearch
            // 
            this.sensorAIterativeSearch.Location = new System.Drawing.Point(221, 109);
            this.sensorAIterativeSearch.Name = "sensorAIterativeSearch";
            this.sensorAIterativeSearch.Size = new System.Drawing.Size(100, 23);
            this.sensorAIterativeSearch.TabIndex = 2;
            this.sensorAIterativeSearch.Text = "Search";
            this.sensorAIterativeSearch.UseVisualStyleBackColor = true;
            // 
            // sensorAListBox
            // 
            this.sensorAListBox.FormattingEnabled = true;
            this.sensorAListBox.Location = new System.Drawing.Point(356, 93);
            this.sensorAListBox.Name = "sensorAListBox";
            this.sensorAListBox.Size = new System.Drawing.Size(120, 446);
            this.sensorAListBox.TabIndex = 3;
            // 
            // sensorBListBox
            // 
            this.sensorBListBox.FormattingEnabled = true;
            this.sensorBListBox.Location = new System.Drawing.Point(616, 93);
            this.sensorBListBox.Name = "sensorBListBox";
            this.sensorBListBox.Size = new System.Drawing.Size(120, 446);
            this.sensorBListBox.TabIndex = 4;
            // 
            // sensorARecursiveSearch
            // 
            this.sensorARecursiveSearch.Location = new System.Drawing.Point(221, 215);
            this.sensorARecursiveSearch.Name = "sensorARecursiveSearch";
            this.sensorARecursiveSearch.Size = new System.Drawing.Size(100, 23);
            this.sensorARecursiveSearch.TabIndex = 5;
            this.sensorARecursiveSearch.Text = "Search";
            this.sensorARecursiveSearch.UseVisualStyleBackColor = true;
            // 
            // sensorASelectionSort
            // 
            this.sensorASelectionSort.Location = new System.Drawing.Point(221, 385);
            this.sensorASelectionSort.Name = "sensorASelectionSort";
            this.sensorASelectionSort.Size = new System.Drawing.Size(100, 23);
            this.sensorASelectionSort.TabIndex = 6;
            this.sensorASelectionSort.Text = "Sort";
            this.sensorASelectionSort.UseVisualStyleBackColor = true;
            // 
            // sensorAInsertionSort
            // 
            this.sensorAInsertionSort.Location = new System.Drawing.Point(221, 490);
            this.sensorAInsertionSort.Name = "sensorAInsertionSort";
            this.sensorAInsertionSort.Size = new System.Drawing.Size(100, 23);
            this.sensorAInsertionSort.TabIndex = 7;
            this.sensorAInsertionSort.Text = "Sort";
            this.sensorAInsertionSort.UseVisualStyleBackColor = true;
            // 
            // sensorBIterativeSearch
            // 
            this.sensorBIterativeSearch.Location = new System.Drawing.Point(500, 109);
            this.sensorBIterativeSearch.Name = "sensorBIterativeSearch";
            this.sensorBIterativeSearch.Size = new System.Drawing.Size(100, 23);
            this.sensorBIterativeSearch.TabIndex = 8;
            this.sensorBIterativeSearch.Text = "Search";
            this.sensorBIterativeSearch.UseVisualStyleBackColor = true;
            // 
            // sensorBRecursiveSearch
            // 
            this.sensorBRecursiveSearch.Location = new System.Drawing.Point(500, 215);
            this.sensorBRecursiveSearch.Name = "sensorBRecursiveSearch";
            this.sensorBRecursiveSearch.Size = new System.Drawing.Size(100, 23);
            this.sensorBRecursiveSearch.TabIndex = 9;
            this.sensorBRecursiveSearch.Text = "Search";
            this.sensorBRecursiveSearch.UseVisualStyleBackColor = true;
            // 
            // sensorBSelectionSort
            // 
            this.sensorBSelectionSort.Location = new System.Drawing.Point(500, 385);
            this.sensorBSelectionSort.Name = "sensorBSelectionSort";
            this.sensorBSelectionSort.Size = new System.Drawing.Size(100, 23);
            this.sensorBSelectionSort.TabIndex = 10;
            this.sensorBSelectionSort.Text = "Sort";
            this.sensorBSelectionSort.UseVisualStyleBackColor = true;
            // 
            // sensorBInsertionSort
            // 
            this.sensorBInsertionSort.Location = new System.Drawing.Point(500, 490);
            this.sensorBInsertionSort.Name = "sensorBInsertionSort";
            this.sensorBInsertionSort.Size = new System.Drawing.Size(100, 23);
            this.sensorBInsertionSort.TabIndex = 11;
            this.sensorBInsertionSort.Text = "Sort";
            this.sensorBInsertionSort.UseVisualStyleBackColor = true;
            // 
            // sigmaUpDown
            // 
            this.sigmaUpDown.Location = new System.Drawing.Point(50, 38);
            this.sigmaUpDown.Name = "sigmaUpDown";
            this.sigmaUpDown.Size = new System.Drawing.Size(46, 20);
            this.sigmaUpDown.TabIndex = 12;
            this.sigmaUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // muUpDown
            // 
            this.muUpDown.Location = new System.Drawing.Point(125, 38);
            this.muUpDown.Name = "muUpDown";
            this.muUpDown.Size = new System.Drawing.Size(46, 20);
            this.muUpDown.TabIndex = 13;
            this.muUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // sensorAIterativeText
            // 
            this.sensorAIterativeText.Location = new System.Drawing.Point(221, 138);
            this.sensorAIterativeText.Name = "sensorAIterativeText";
            this.sensorAIterativeText.Size = new System.Drawing.Size(100, 20);
            this.sensorAIterativeText.TabIndex = 14;
            // 
            // sensorBIterativeText
            // 
            this.sensorBIterativeText.Location = new System.Drawing.Point(500, 138);
            this.sensorBIterativeText.Name = "sensorBIterativeText";
            this.sensorBIterativeText.Size = new System.Drawing.Size(100, 20);
            this.sensorBIterativeText.TabIndex = 15;
            // 
            // sensorARecursiveText
            // 
            this.sensorARecursiveText.Location = new System.Drawing.Point(221, 244);
            this.sensorARecursiveText.Name = "sensorARecursiveText";
            this.sensorARecursiveText.Size = new System.Drawing.Size(100, 20);
            this.sensorARecursiveText.TabIndex = 16;
            // 
            // sensorBRecursiveText
            // 
            this.sensorBRecursiveText.Location = new System.Drawing.Point(500, 244);
            this.sensorBRecursiveText.Name = "sensorBRecursiveText";
            this.sensorBRecursiveText.Size = new System.Drawing.Size(100, 20);
            this.sensorBRecursiveText.TabIndex = 17;
            // 
            // sensorASelectionText
            // 
            this.sensorASelectionText.Location = new System.Drawing.Point(221, 415);
            this.sensorASelectionText.Name = "sensorASelectionText";
            this.sensorASelectionText.Size = new System.Drawing.Size(100, 20);
            this.sensorASelectionText.TabIndex = 18;
            // 
            // sensorBSelectionText
            // 
            this.sensorBSelectionText.Location = new System.Drawing.Point(500, 415);
            this.sensorBSelectionText.Name = "sensorBSelectionText";
            this.sensorBSelectionText.Size = new System.Drawing.Size(100, 20);
            this.sensorBSelectionText.TabIndex = 19;
            // 
            // sensorAInsertionText
            // 
            this.sensorAInsertionText.Location = new System.Drawing.Point(221, 519);
            this.sensorAInsertionText.Name = "sensorAInsertionText";
            this.sensorAInsertionText.Size = new System.Drawing.Size(100, 20);
            this.sensorAInsertionText.TabIndex = 20;
            // 
            // sensorBInsertionText
            // 
            this.sensorBInsertionText.Location = new System.Drawing.Point(500, 519);
            this.sensorBInsertionText.Name = "sensorBInsertionText";
            this.sensorBInsertionText.Size = new System.Drawing.Size(100, 20);
            this.sensorBInsertionText.TabIndex = 21;
            // 
            // searchTargetAText
            // 
            this.searchTargetAText.Location = new System.Drawing.Point(221, 316);
            this.searchTargetAText.Name = "searchTargetAText";
            this.searchTargetAText.Size = new System.Drawing.Size(100, 20);
            this.searchTargetAText.TabIndex = 22;
            // 
            // searchTargetBText
            // 
            this.searchTargetBText.Location = new System.Drawing.Point(500, 316);
            this.searchTargetBText.Name = "searchTargetBText";
            this.searchTargetBText.Size = new System.Drawing.Size(100, 20);
            this.searchTargetBText.TabIndex = 23;
            // 
            // Sigma
            // 
            this.Sigma.AutoSize = true;
            this.Sigma.Location = new System.Drawing.Point(47, 21);
            this.Sigma.Name = "Sigma";
            this.Sigma.Size = new System.Drawing.Size(36, 13);
            this.Sigma.TabIndex = 24;
            this.Sigma.Text = "Sigma";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "Mu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(218, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 26;
            this.label3.Text = "Iterative Search";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(218, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Recursive Search";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(218, 294);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Search Target";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(218, 369);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "Selection Sort";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(218, 471);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 30;
            this.label7.Text = "Insertion Sort";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(497, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 31;
            this.label8.Text = "Iterative Search";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(497, 199);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 13);
            this.label9.TabIndex = 32;
            this.label9.Text = "Recursive Search";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(497, 294);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 33;
            this.label10.Text = "Search Target";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(497, 369);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 34;
            this.label11.Text = "Selection Sort";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(497, 471);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 13);
            this.label12.TabIndex = 35;
            this.label12.Text = "Insertion Sort";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(256, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 39);
            this.label1.TabIndex = 36;
            this.label1.Text = "Sensor A";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(530, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(167, 39);
            this.label13.TabIndex = 37;
            this.label13.Text = "Sensor B";
            // 
            // DataProcessing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 566);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Sigma);
            this.Controls.Add(this.searchTargetBText);
            this.Controls.Add(this.searchTargetAText);
            this.Controls.Add(this.sensorBInsertionText);
            this.Controls.Add(this.sensorAInsertionText);
            this.Controls.Add(this.sensorBSelectionText);
            this.Controls.Add(this.sensorASelectionText);
            this.Controls.Add(this.sensorBRecursiveText);
            this.Controls.Add(this.sensorARecursiveText);
            this.Controls.Add(this.sensorBIterativeText);
            this.Controls.Add(this.sensorAIterativeText);
            this.Controls.Add(this.muUpDown);
            this.Controls.Add(this.sigmaUpDown);
            this.Controls.Add(this.sensorBInsertionSort);
            this.Controls.Add(this.sensorBSelectionSort);
            this.Controls.Add(this.sensorBRecursiveSearch);
            this.Controls.Add(this.sensorBIterativeSearch);
            this.Controls.Add(this.sensorAInsertionSort);
            this.Controls.Add(this.sensorASelectionSort);
            this.Controls.Add(this.sensorARecursiveSearch);
            this.Controls.Add(this.sensorBListBox);
            this.Controls.Add(this.sensorAListBox);
            this.Controls.Add(this.sensorAIterativeSearch);
            this.Controls.Add(this.sensorListView);
            this.Controls.Add(this.loadSensorData);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DataProcessing";
            this.Text = "Data Processing";
            ((System.ComponentModel.ISupportInitialize)(this.sigmaUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.muUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loadSensorData;
        private System.Windows.Forms.ListView sensorListView;
        private System.Windows.Forms.ColumnHeader Sensor_A;
        private System.Windows.Forms.ColumnHeader Sensor_B;
        private System.Windows.Forms.Button sensorAIterativeSearch;
        private System.Windows.Forms.ListBox sensorAListBox;
        private System.Windows.Forms.ListBox sensorBListBox;
        private System.Windows.Forms.Button sensorARecursiveSearch;
        private System.Windows.Forms.Button sensorASelectionSort;
        private System.Windows.Forms.Button sensorAInsertionSort;
        private System.Windows.Forms.Button sensorBIterativeSearch;
        private System.Windows.Forms.Button sensorBRecursiveSearch;
        private System.Windows.Forms.Button sensorBSelectionSort;
        private System.Windows.Forms.Button sensorBInsertionSort;
        private System.Windows.Forms.NumericUpDown sigmaUpDown;
        private System.Windows.Forms.NumericUpDown muUpDown;
        private System.Windows.Forms.TextBox sensorAIterativeText;
        private System.Windows.Forms.TextBox sensorBIterativeText;
        private System.Windows.Forms.TextBox sensorARecursiveText;
        private System.Windows.Forms.TextBox sensorBRecursiveText;
        private System.Windows.Forms.TextBox sensorASelectionText;
        private System.Windows.Forms.TextBox sensorBSelectionText;
        private System.Windows.Forms.TextBox sensorAInsertionText;
        private System.Windows.Forms.TextBox sensorBInsertionText;
        private System.Windows.Forms.TextBox searchTargetAText;
        private System.Windows.Forms.TextBox searchTargetBText;
        private System.Windows.Forms.Label Sigma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label13;
    }
}

